﻿namespace Voidbot_Discord_Bot_GUI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            nsTabControl1 = new NSTabControl();
            tabPage1 = new TabPage();
            nsGroupBox3 = new NSGroupBox();
            nsLabel45 = new NSLabel();
            MongoDBName = new NSTextBox();
            nsLabel44 = new NSLabel();
            MongoClientLink = new NSTextBox();
            nsComboBox9 = new NSComboBox();
            nsComboBox8 = new NSComboBox();
            nsComboBox7 = new NSComboBox();
            ServerID = new NSTextBox();
            nsLabel23 = new NSLabel();
            nsLabel16 = new NSLabel();
            nsLabel13 = new NSLabel();
            nsLabel12 = new NSLabel();
            BotNickname = new NSTextBox();
            nsLabel11 = new NSLabel();
            nsLabel14 = new NSLabel();
            nsLabel15 = new NSLabel();
            InviteLink = new NSTextBox();
            nsGroupBox2 = new NSGroupBox();
            nsComboBox11 = new NSComboBox();
            nsComboBox10 = new NSComboBox();
            nsLabel43 = new NSLabel();
            nsLabel42 = new NSLabel();
            nsLabel7 = new NSLabel();
            nsGroupBox1 = new NSGroupBox();
            nsCheckBox1 = new NSCheckBox();
            nsLabel6 = new NSLabel();
            YoutubeAPIKey = new NSTextBox();
            nsLabel4 = new NSLabel();
            YoutubeAppName = new NSTextBox();
            nsLabel3 = new NSLabel();
            DiscordBotToken = new NSTextBox();
            nsLabel2 = new NSLabel();
            nsGroupBox4 = new NSGroupBox();
            pictureBox1 = new PictureBox();
            nsLabel20 = new NSLabel();
            nsLabel22 = new NSLabel();
            nsLabel19 = new NSLabel();
            nsGroupBox5 = new NSGroupBox();
            nsCheckBox4 = new NSCheckBox();
            nsButton5 = new NSButton();
            label2 = new Label();
            label1 = new Label();
            nsGroupBox6 = new NSGroupBox();
            nsButton3 = new NSButton();
            nsButton1 = new NSButton();
            nsButton2 = new NSButton();
            nsGroupBox8 = new NSGroupBox();
            linkLabel3 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            tabPage2 = new TabPage();
            botConsoleView = new TextBox();
            nsGroupBox7 = new NSGroupBox();
            nsButton4 = new NSButton();
            nsLabel18 = new NSLabel();
            nsGroupBox9 = new NSGroupBox();
            nsComboBox2 = new NSComboBox();
            nsButton11 = new NSButton();
            nsComboBox1 = new NSComboBox();
            consolebtnSend = new NSButton();
            commandInputConsoleview = new NSTextBox();
            nsLabel21 = new NSLabel();
            tabPage3 = new TabPage();
            nsGroupBox10 = new NSGroupBox();
            nsLabel30 = new NSLabel();
            nsLabel29 = new NSLabel();
            nsLabel28 = new NSLabel();
            nsGroupBox12 = new NSGroupBox();
            nsButton12 = new NSButton();
            nsTextBox2 = new NSTextBox();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            nsLabel27 = new NSLabel();
            nsButton9 = new NSButton();
            nsButton10 = new NSButton();
            label11 = new Label();
            label12 = new Label();
            nsGroupBox11 = new NSGroupBox();
            nsTextBox1 = new NSTextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            nsLabel24 = new NSLabel();
            nsButton8 = new NSButton();
            nsButton7 = new NSButton();
            label7 = new Label();
            label6 = new Label();
            nsLabel26 = new NSLabel();
            nsListView2 = new NSListView();
            nsListView1 = new NSListView();
            notifyIcon1 = new NotifyIcon(components);
            nsContextMenu1 = new NSContextMenu();
            openBotPanelToolStripMenuItem = new ToolStripMenuItem();
            closeBotToolStripMenuItem = new ToolStripMenuItem();
            timer1 = new System.Windows.Forms.Timer(components);
            nsTabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            nsGroupBox3.SuspendLayout();
            nsGroupBox2.SuspendLayout();
            nsGroupBox1.SuspendLayout();
            nsGroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            nsGroupBox5.SuspendLayout();
            nsGroupBox6.SuspendLayout();
            nsGroupBox8.SuspendLayout();
            tabPage2.SuspendLayout();
            nsGroupBox7.SuspendLayout();
            nsGroupBox9.SuspendLayout();
            tabPage3.SuspendLayout();
            nsGroupBox10.SuspendLayout();
            nsGroupBox12.SuspendLayout();
            nsGroupBox11.SuspendLayout();
            nsContextMenu1.SuspendLayout();
            SuspendLayout();
            // 
            // nsTabControl1
            // 
            nsTabControl1.Alignment = TabAlignment.Left;
            nsTabControl1.Controls.Add(tabPage1);
            nsTabControl1.Controls.Add(tabPage2);
            nsTabControl1.Controls.Add(tabPage3);
            nsTabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
            nsTabControl1.ItemSize = new Size(28, 115);
            nsTabControl1.Location = new Point(1, -3);
            nsTabControl1.Multiline = true;
            nsTabControl1.Name = "nsTabControl1";
            nsTabControl1.SelectedIndex = 0;
            nsTabControl1.Size = new Size(1156, 491);
            nsTabControl1.SizeMode = TabSizeMode.Fixed;
            nsTabControl1.TabIndex = 34;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(50, 50, 50);
            tabPage1.Controls.Add(nsGroupBox3);
            tabPage1.Controls.Add(nsGroupBox2);
            tabPage1.Controls.Add(nsGroupBox1);
            tabPage1.Controls.Add(nsGroupBox4);
            tabPage1.Controls.Add(nsGroupBox5);
            tabPage1.Controls.Add(nsGroupBox6);
            tabPage1.Controls.Add(nsGroupBox8);
            tabPage1.Location = new Point(119, 4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1033, 483);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Bot Main Page";
            // 
            // nsGroupBox3
            // 
            nsGroupBox3.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox3.Controls.Add(nsLabel45);
            nsGroupBox3.Controls.Add(MongoDBName);
            nsGroupBox3.Controls.Add(nsLabel44);
            nsGroupBox3.Controls.Add(MongoClientLink);
            nsGroupBox3.Controls.Add(nsComboBox9);
            nsGroupBox3.Controls.Add(nsComboBox8);
            nsGroupBox3.Controls.Add(nsComboBox7);
            nsGroupBox3.Controls.Add(ServerID);
            nsGroupBox3.Controls.Add(nsLabel23);
            nsGroupBox3.Controls.Add(nsLabel16);
            nsGroupBox3.Controls.Add(nsLabel13);
            nsGroupBox3.Controls.Add(nsLabel12);
            nsGroupBox3.Controls.Add(BotNickname);
            nsGroupBox3.Controls.Add(nsLabel11);
            nsGroupBox3.Controls.Add(nsLabel14);
            nsGroupBox3.Controls.Add(nsLabel15);
            nsGroupBox3.Controls.Add(InviteLink);
            nsGroupBox3.DrawSeperator = false;
            nsGroupBox3.Location = new Point(545, 75);
            nsGroupBox3.Name = "nsGroupBox3";
            nsGroupBox3.Size = new Size(486, 300);
            nsGroupBox3.SubTitle = "";
            nsGroupBox3.TabIndex = 35;
            nsGroupBox3.Text = "nsGroupBox3";
            nsGroupBox3.Title = "";
            // 
            // nsLabel45
            // 
            nsLabel45.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel45.Location = new Point(6, 228);
            nsLabel45.Name = "nsLabel45";
            nsLabel45.Size = new Size(147, 23);
            nsLabel45.TabIndex = 36;
            nsLabel45.Text = "nsLabel45";
            nsLabel45.Value1 = "MongoDB Name:";
            nsLabel45.Value2 = " ";
            // 
            // MongoDBName
            // 
            MongoDBName.Location = new Point(157, 228);
            MongoDBName.MaxLength = 32767;
            MongoDBName.Multiline = false;
            MongoDBName.Name = "MongoDBName";
            MongoDBName.ReadOnly = false;
            MongoDBName.Size = new Size(313, 23);
            MongoDBName.TabIndex = 35;
            MongoDBName.TextAlign = HorizontalAlignment.Left;
            MongoDBName.UseSystemPasswordChar = true;
            // 
            // nsLabel44
            // 
            nsLabel44.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel44.Location = new Point(4, 199);
            nsLabel44.Name = "nsLabel44";
            nsLabel44.Size = new Size(147, 23);
            nsLabel44.TabIndex = 34;
            nsLabel44.Text = "nsLabel44";
            nsLabel44.Value1 = "MongoDB Client Link:";
            nsLabel44.Value2 = " ";
            // 
            // MongoClientLink
            // 
            MongoClientLink.Location = new Point(157, 199);
            MongoClientLink.MaxLength = 32767;
            MongoClientLink.Multiline = false;
            MongoClientLink.Name = "MongoClientLink";
            MongoClientLink.ReadOnly = false;
            MongoClientLink.Size = new Size(313, 23);
            MongoClientLink.TabIndex = 33;
            MongoClientLink.TextAlign = HorizontalAlignment.Left;
            MongoClientLink.UseSystemPasswordChar = true;
            // 
            // nsComboBox9
            // 
            nsComboBox9.BackColor = Color.FromArgb(50, 50, 50);
            nsComboBox9.DrawMode = DrawMode.OwnerDrawFixed;
            nsComboBox9.DropDownStyle = ComboBoxStyle.DropDownList;
            nsComboBox9.ForeColor = Color.White;
            nsComboBox9.FormattingEnabled = true;
            nsComboBox9.Location = new Point(157, 140);
            nsComboBox9.Name = "nsComboBox9";
            nsComboBox9.Size = new Size(313, 24);
            nsComboBox9.TabIndex = 32;
            // 
            // nsComboBox8
            // 
            nsComboBox8.BackColor = Color.FromArgb(50, 50, 50);
            nsComboBox8.DrawMode = DrawMode.OwnerDrawFixed;
            nsComboBox8.DropDownStyle = ComboBoxStyle.DropDownList;
            nsComboBox8.ForeColor = Color.White;
            nsComboBox8.FormattingEnabled = true;
            nsComboBox8.Location = new Point(157, 111);
            nsComboBox8.Name = "nsComboBox8";
            nsComboBox8.Size = new Size(313, 24);
            nsComboBox8.TabIndex = 31;
            // 
            // nsComboBox7
            // 
            nsComboBox7.BackColor = Color.FromArgb(50, 50, 50);
            nsComboBox7.DrawMode = DrawMode.OwnerDrawFixed;
            nsComboBox7.DropDownStyle = ComboBoxStyle.DropDownList;
            nsComboBox7.ForeColor = Color.White;
            nsComboBox7.FormattingEnabled = true;
            nsComboBox7.Location = new Point(157, 83);
            nsComboBox7.Name = "nsComboBox7";
            nsComboBox7.Size = new Size(313, 24);
            nsComboBox7.TabIndex = 30;
            // 
            // ServerID
            // 
            ServerID.Location = new Point(157, 25);
            ServerID.MaxLength = 32767;
            ServerID.Multiline = false;
            ServerID.Name = "ServerID";
            ServerID.ReadOnly = false;
            ServerID.Size = new Size(313, 23);
            ServerID.TabIndex = 27;
            ServerID.TextAlign = HorizontalAlignment.Left;
            ServerID.UseSystemPasswordChar = false;
            // 
            // nsLabel23
            // 
            nsLabel23.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel23.Location = new Point(6, 25);
            nsLabel23.Name = "nsLabel23";
            nsLabel23.Size = new Size(123, 23);
            nsLabel23.TabIndex = 28;
            nsLabel23.Text = "nsLabel23";
            nsLabel23.Value1 = "Your Server ID: ";
            nsLabel23.Value2 = " ";
            // 
            // nsLabel16
            // 
            nsLabel16.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel16.Location = new Point(4, 170);
            nsLabel16.Name = "nsLabel16";
            nsLabel16.Size = new Size(87, 23);
            nsLabel16.TabIndex = 25;
            nsLabel16.Text = "nsLabel16";
            nsLabel16.Value1 = "Bot Name: ";
            nsLabel16.Value2 = " ";
            // 
            // nsLabel13
            // 
            nsLabel13.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel13.Location = new Point(4, 141);
            nsLabel13.Name = "nsLabel13";
            nsLabel13.Size = new Size(140, 23);
            nsLabel13.TabIndex = 24;
            nsLabel13.Text = "nsLabel13";
            nsLabel13.Value1 = "Streamer Role ID:";
            nsLabel13.Value2 = " ";
            // 
            // nsLabel12
            // 
            nsLabel12.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel12.Location = new Point(4, 112);
            nsLabel12.Name = "nsLabel12";
            nsLabel12.Size = new Size(140, 23);
            nsLabel12.TabIndex = 23;
            nsLabel12.Text = "nsLabel12";
            nsLabel12.Value1 = "Moderator Role ID:";
            nsLabel12.Value2 = " ";
            // 
            // BotNickname
            // 
            BotNickname.Location = new Point(157, 170);
            BotNickname.MaxLength = 32767;
            BotNickname.Multiline = false;
            BotNickname.Name = "BotNickname";
            BotNickname.ReadOnly = false;
            BotNickname.Size = new Size(313, 23);
            BotNickname.TabIndex = 14;
            BotNickname.TextAlign = HorizontalAlignment.Left;
            BotNickname.UseSystemPasswordChar = false;
            // 
            // nsLabel11
            // 
            nsLabel11.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel11.Location = new Point(4, 83);
            nsLabel11.Name = "nsLabel11";
            nsLabel11.Size = new Size(103, 23);
            nsLabel11.TabIndex = 22;
            nsLabel11.Text = "nsLabel11";
            nsLabel11.Value1 = "AutoRole ID:";
            nsLabel11.Value2 = " ";
            // 
            // nsLabel14
            // 
            nsLabel14.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            nsLabel14.Location = new Point(4, 3);
            nsLabel14.Name = "nsLabel14";
            nsLabel14.Size = new Size(161, 23);
            nsLabel14.TabIndex = 21;
            nsLabel14.Text = "nsLabel14";
            nsLabel14.Value1 = "Bot";
            nsLabel14.Value2 = " Discord Settings";
            // 
            // nsLabel15
            // 
            nsLabel15.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel15.Location = new Point(4, 54);
            nsLabel15.Name = "nsLabel15";
            nsLabel15.Size = new Size(123, 23);
            nsLabel15.TabIndex = 20;
            nsLabel15.Text = "nsLabel15";
            nsLabel15.Value1 = "Permanent Link:";
            nsLabel15.Value2 = " ";
            // 
            // InviteLink
            // 
            InviteLink.Location = new Point(157, 54);
            InviteLink.MaxLength = 32767;
            InviteLink.Multiline = false;
            InviteLink.Name = "InviteLink";
            InviteLink.ReadOnly = false;
            InviteLink.Size = new Size(313, 23);
            InviteLink.TabIndex = 10;
            InviteLink.TextAlign = HorizontalAlignment.Left;
            InviteLink.UseSystemPasswordChar = false;
            // 
            // nsGroupBox2
            // 
            nsGroupBox2.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox2.Controls.Add(nsComboBox11);
            nsGroupBox2.Controls.Add(nsComboBox10);
            nsGroupBox2.Controls.Add(nsLabel43);
            nsGroupBox2.Controls.Add(nsLabel42);
            nsGroupBox2.Controls.Add(nsLabel7);
            nsGroupBox2.DrawSeperator = false;
            nsGroupBox2.Location = new Point(0, 245);
            nsGroupBox2.Name = "nsGroupBox2";
            nsGroupBox2.Size = new Size(545, 215);
            nsGroupBox2.SubTitle = "";
            nsGroupBox2.TabIndex = 34;
            nsGroupBox2.Text = "nsGroupBox2";
            nsGroupBox2.Title = "";
            // 
            // nsComboBox11
            // 
            nsComboBox11.BackColor = Color.FromArgb(50, 50, 50);
            nsComboBox11.DrawMode = DrawMode.OwnerDrawFixed;
            nsComboBox11.DropDownStyle = ComboBoxStyle.DropDownList;
            nsComboBox11.ForeColor = Color.White;
            nsComboBox11.FormattingEnabled = true;
            nsComboBox11.Location = new Point(190, 57);
            nsComboBox11.Name = "nsComboBox11";
            nsComboBox11.Size = new Size(334, 24);
            nsComboBox11.TabIndex = 34;
            // 
            // nsComboBox10
            // 
            nsComboBox10.BackColor = Color.FromArgb(50, 50, 50);
            nsComboBox10.DrawMode = DrawMode.OwnerDrawFixed;
            nsComboBox10.DropDownStyle = ComboBoxStyle.DropDownList;
            nsComboBox10.ForeColor = Color.White;
            nsComboBox10.FormattingEnabled = true;
            nsComboBox10.Location = new Point(190, 28);
            nsComboBox10.Name = "nsComboBox10";
            nsComboBox10.Size = new Size(334, 24);
            nsComboBox10.TabIndex = 33;
            // 
            // nsLabel43
            // 
            nsLabel43.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel43.Location = new Point(4, 58);
            nsLabel43.Name = "nsLabel43";
            nsLabel43.Size = new Size(143, 23);
            nsLabel43.TabIndex = 26;
            nsLabel43.Text = "nsLabel43";
            nsLabel43.Value1 = "Rules Channel:";
            nsLabel43.Value2 = " ";
            // 
            // nsLabel42
            // 
            nsLabel42.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel42.Location = new Point(4, 29);
            nsLabel42.Name = "nsLabel42";
            nsLabel42.Size = new Size(191, 23);
            nsLabel42.TabIndex = 25;
            nsLabel42.Text = "nsLabel42";
            nsLabel42.Value1 = "Verify & Welcomes Channel:";
            nsLabel42.Value2 = " ";
            // 
            // nsLabel7
            // 
            nsLabel7.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            nsLabel7.Location = new Point(4, 3);
            nsLabel7.Name = "nsLabel7";
            nsLabel7.Size = new Size(538, 23);
            nsLabel7.TabIndex = 21;
            nsLabel7.Text = "nsLabel7";
            nsLabel7.Value1 = "Bot Channel Settings";
            nsLabel7.Value2 = "(Deprecated, Left as example)";
            // 
            // nsGroupBox1
            // 
            nsGroupBox1.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox1.Controls.Add(nsCheckBox1);
            nsGroupBox1.Controls.Add(nsLabel6);
            nsGroupBox1.Controls.Add(YoutubeAPIKey);
            nsGroupBox1.Controls.Add(nsLabel4);
            nsGroupBox1.Controls.Add(YoutubeAppName);
            nsGroupBox1.Controls.Add(nsLabel3);
            nsGroupBox1.Controls.Add(DiscordBotToken);
            nsGroupBox1.Controls.Add(nsLabel2);
            nsGroupBox1.DrawSeperator = false;
            nsGroupBox1.Location = new Point(0, 75);
            nsGroupBox1.Name = "nsGroupBox1";
            nsGroupBox1.Size = new Size(545, 167);
            nsGroupBox1.SubTitle = "";
            nsGroupBox1.TabIndex = 33;
            nsGroupBox1.Text = "nsGroupBox1";
            nsGroupBox1.Title = "";
            // 
            // nsCheckBox1
            // 
            nsCheckBox1.Checked = false;
            nsCheckBox1.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsCheckBox1.Location = new Point(342, 6);
            nsCheckBox1.Name = "nsCheckBox1";
            nsCheckBox1.Size = new Size(182, 23);
            nsCheckBox1.TabIndex = 22;
            nsCheckBox1.Text = "Show Keys/ Sensitive Info";
            nsCheckBox1.CheckedChanged += nsCheckBox1_CheckedChanged;
            // 
            // nsLabel6
            // 
            nsLabel6.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            nsLabel6.Location = new Point(3, 3);
            nsLabel6.Name = "nsLabel6";
            nsLabel6.Size = new Size(129, 23);
            nsLabel6.TabIndex = 21;
            nsLabel6.Text = "nsLabel6";
            nsLabel6.Value1 = "Bot API";
            nsLabel6.Value2 = " Settings";
            // 
            // YoutubeAPIKey
            // 
            YoutubeAPIKey.Location = new Point(156, 49);
            YoutubeAPIKey.MaxLength = 32767;
            YoutubeAPIKey.Multiline = false;
            YoutubeAPIKey.Name = "YoutubeAPIKey";
            YoutubeAPIKey.ReadOnly = false;
            YoutubeAPIKey.Size = new Size(368, 23);
            YoutubeAPIKey.TabIndex = 3;
            YoutubeAPIKey.TextAlign = HorizontalAlignment.Left;
            YoutubeAPIKey.UseSystemPasswordChar = true;
            // 
            // nsLabel4
            // 
            nsLabel4.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel4.Location = new Point(3, 108);
            nsLabel4.Name = "nsLabel4";
            nsLabel4.Size = new Size(143, 23);
            nsLabel4.TabIndex = 19;
            nsLabel4.Text = "nsLabel4";
            nsLabel4.Value1 = "Discord Bot Token:";
            nsLabel4.Value2 = " ";
            // 
            // YoutubeAppName
            // 
            YoutubeAppName.Location = new Point(156, 78);
            YoutubeAppName.MaxLength = 32767;
            YoutubeAppName.Multiline = false;
            YoutubeAppName.Name = "YoutubeAppName";
            YoutubeAppName.ReadOnly = false;
            YoutubeAppName.Size = new Size(368, 23);
            YoutubeAppName.TabIndex = 4;
            YoutubeAppName.TextAlign = HorizontalAlignment.Left;
            YoutubeAppName.UseSystemPasswordChar = true;
            // 
            // nsLabel3
            // 
            nsLabel3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel3.Location = new Point(4, 79);
            nsLabel3.Name = "nsLabel3";
            nsLabel3.Size = new Size(143, 23);
            nsLabel3.TabIndex = 18;
            nsLabel3.Text = "nsLabel3";
            nsLabel3.Value1 = "Youtube API Name:";
            nsLabel3.Value2 = " ";
            // 
            // DiscordBotToken
            // 
            DiscordBotToken.Location = new Point(156, 107);
            DiscordBotToken.MaxLength = 32767;
            DiscordBotToken.Multiline = false;
            DiscordBotToken.Name = "DiscordBotToken";
            DiscordBotToken.ReadOnly = false;
            DiscordBotToken.Size = new Size(368, 27);
            DiscordBotToken.TabIndex = 5;
            DiscordBotToken.TextAlign = HorizontalAlignment.Left;
            DiscordBotToken.UseSystemPasswordChar = true;
            // 
            // nsLabel2
            // 
            nsLabel2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold);
            nsLabel2.Location = new Point(4, 49);
            nsLabel2.Name = "nsLabel2";
            nsLabel2.Size = new Size(134, 23);
            nsLabel2.TabIndex = 17;
            nsLabel2.Text = "nsLabel2";
            nsLabel2.Value1 = "Youtube API Key:";
            nsLabel2.Value2 = " ";
            // 
            // nsGroupBox4
            // 
            nsGroupBox4.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox4.Controls.Add(pictureBox1);
            nsGroupBox4.Controls.Add(nsLabel20);
            nsGroupBox4.Controls.Add(nsLabel22);
            nsGroupBox4.Controls.Add(nsLabel19);
            nsGroupBox4.DrawSeperator = false;
            nsGroupBox4.Location = new Point(0, 1);
            nsGroupBox4.Name = "nsGroupBox4";
            nsGroupBox4.Size = new Size(545, 75);
            nsGroupBox4.SubTitle = "";
            nsGroupBox4.TabIndex = 36;
            nsGroupBox4.Text = "nsGroupBox4";
            nsGroupBox4.Title = "";
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = Properties.Resources._2451296;
            pictureBox1.Location = new Point(6, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(70, 70);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 33;
            pictureBox1.TabStop = false;
            // 
            // nsLabel20
            // 
            nsLabel20.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            nsLabel20.Location = new Point(83, 26);
            nsLabel20.Name = "nsLabel20";
            nsLabel20.Size = new Size(421, 19);
            nsLabel20.TabIndex = 31;
            nsLabel20.Text = "nsLabel20";
            nsLabel20.Value1 = "Bot Name: ";
            nsLabel20.Value2 = " ";
            // 
            // nsLabel22
            // 
            nsLabel22.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            nsLabel22.Location = new Point(83, 47);
            nsLabel22.Name = "nsLabel22";
            nsLabel22.Size = new Size(207, 21);
            nsLabel22.TabIndex = 34;
            nsLabel22.Text = "nsLabel22";
            nsLabel22.Value1 = "Online Status: ";
            nsLabel22.Value2 = " ";
            // 
            // nsLabel19
            // 
            nsLabel19.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsLabel19.Location = new Point(203, 5);
            nsLabel19.Name = "nsLabel19";
            nsLabel19.Size = new Size(198, 23);
            nsLabel19.TabIndex = 30;
            nsLabel19.Text = "nsLabel19";
            nsLabel19.Value1 = "Discord Bot";
            nsLabel19.Value2 = " Information";
            // 
            // nsGroupBox5
            // 
            nsGroupBox5.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox5.Controls.Add(nsCheckBox4);
            nsGroupBox5.Controls.Add(nsButton5);
            nsGroupBox5.Controls.Add(label2);
            nsGroupBox5.Controls.Add(label1);
            nsGroupBox5.DrawSeperator = false;
            nsGroupBox5.Location = new Point(545, 1);
            nsGroupBox5.Name = "nsGroupBox5";
            nsGroupBox5.Size = new Size(486, 75);
            nsGroupBox5.SubTitle = "";
            nsGroupBox5.TabIndex = 37;
            nsGroupBox5.Text = "nsGroupBox5";
            nsGroupBox5.Title = "";
            // 
            // nsCheckBox4
            // 
            nsCheckBox4.Checked = false;
            nsCheckBox4.Location = new Point(6, 5);
            nsCheckBox4.Name = "nsCheckBox4";
            nsCheckBox4.Size = new Size(80, 26);
            nsCheckBox4.TabIndex = 0;
            nsCheckBox4.Text = "Autorun";
            nsCheckBox4.CheckedChanged += nsCheckBox4_CheckedChanged;
            // 
            // nsButton5
            // 
            nsButton5.Location = new Point(369, 3);
            nsButton5.Name = "nsButton5";
            nsButton5.Size = new Size(113, 23);
            nsButton5.TabIndex = 29;
            nsButton5.Text = "Minimize To Tray";
            nsButton5.Click += nsButton5_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(192, 0, 0);
            label2.Location = new Point(265, 36);
            label2.Name = "label2";
            label2.Size = new Size(0, 21);
            label2.TabIndex = 28;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(88, 36);
            label1.Name = "label1";
            label1.Size = new Size(181, 21);
            label1.TabIndex = 27;
            label1.Text = "Bot Connection Status: ";
            // 
            // nsGroupBox6
            // 
            nsGroupBox6.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox6.Controls.Add(nsButton3);
            nsGroupBox6.Controls.Add(nsButton1);
            nsGroupBox6.Controls.Add(nsButton2);
            nsGroupBox6.DrawSeperator = false;
            nsGroupBox6.Location = new Point(545, 375);
            nsGroupBox6.Name = "nsGroupBox6";
            nsGroupBox6.Size = new Size(486, 85);
            nsGroupBox6.SubTitle = "";
            nsGroupBox6.TabIndex = 38;
            nsGroupBox6.Text = "nsGroupBox6";
            nsGroupBox6.Title = "";
            // 
            // nsButton3
            // 
            nsButton3.Enabled = false;
            nsButton3.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nsButton3.Location = new Point(244, 45);
            nsButton3.Name = "nsButton3";
            nsButton3.Size = new Size(239, 33);
            nsButton3.TabIndex = 26;
            nsButton3.Text = "Stop Bot";
            nsButton3.Click += nsButton3_Click;
            // 
            // nsButton1
            // 
            nsButton1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nsButton1.Location = new Point(2, 6);
            nsButton1.Name = "nsButton1";
            nsButton1.Size = new Size(479, 33);
            nsButton1.TabIndex = 0;
            nsButton1.Text = "Save Settings...";
            nsButton1.Click += nsButton1_Click;
            // 
            // nsButton2
            // 
            nsButton2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            nsButton2.Location = new Point(3, 45);
            nsButton2.Name = "nsButton2";
            nsButton2.Size = new Size(239, 33);
            nsButton2.TabIndex = 1;
            nsButton2.Text = "Run Bot";
            nsButton2.Click += nsButton2_Click;
            // 
            // nsGroupBox8
            // 
            nsGroupBox8.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox8.Controls.Add(linkLabel3);
            nsGroupBox8.Controls.Add(linkLabel1);
            nsGroupBox8.Controls.Add(linkLabel2);
            nsGroupBox8.DrawSeperator = false;
            nsGroupBox8.Location = new Point(2, 460);
            nsGroupBox8.Name = "nsGroupBox8";
            nsGroupBox8.Size = new Size(1028, 23);
            nsGroupBox8.SubTitle = "";
            nsGroupBox8.TabIndex = 39;
            nsGroupBox8.Text = "nsGroupBox8";
            nsGroupBox8.Title = "";
            // 
            // linkLabel3
            // 
            linkLabel3.AutoSize = true;
            linkLabel3.BackColor = Color.FromArgb(30, 30, 30);
            linkLabel3.LinkColor = Color.White;
            linkLabel3.Location = new Point(808, 4);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(97, 15);
            linkLabel3.TabIndex = 34;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Join Our Discord!";
            linkLabel3.VisitedLinkColor = Color.Silver;
            linkLabel3.LinkClicked += linkLabel3_LinkClicked;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.BackColor = Color.FromArgb(30, 30, 30);
            linkLabel1.LinkColor = Color.White;
            linkLabel1.Location = new Point(7, 3);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(217, 15);
            linkLabel1.TabIndex = 33;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Donate or Subscribe via BuyMeACoffee!";
            linkLabel1.VisitedLinkColor = Color.Silver;
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.BackColor = Color.FromArgb(30, 30, 30);
            linkLabel2.LinkColor = Color.White;
            linkLabel2.Location = new Point(914, 3);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(110, 15);
            linkLabel2.TabIndex = 30;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "My GitHub Projects";
            linkLabel2.VisitedLinkColor = Color.Silver;
            linkLabel2.LinkClicked += linkLabel2_LinkClicked;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.FromArgb(50, 50, 50);
            tabPage2.Controls.Add(botConsoleView);
            tabPage2.Controls.Add(nsGroupBox7);
            tabPage2.Controls.Add(nsGroupBox9);
            tabPage2.Location = new Point(119, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1033, 483);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Console View";
            // 
            // botConsoleView
            // 
            botConsoleView.BackColor = Color.Black;
            botConsoleView.BorderStyle = BorderStyle.FixedSingle;
            botConsoleView.ForeColor = Color.White;
            botConsoleView.Location = new Point(3, 44);
            botConsoleView.Multiline = true;
            botConsoleView.Name = "botConsoleView";
            botConsoleView.ReadOnly = true;
            botConsoleView.ScrollBars = ScrollBars.Vertical;
            botConsoleView.Size = new Size(1030, 332);
            botConsoleView.TabIndex = 32;
            // 
            // nsGroupBox7
            // 
            nsGroupBox7.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox7.Controls.Add(nsButton4);
            nsGroupBox7.Controls.Add(nsLabel18);
            nsGroupBox7.DrawSeperator = false;
            nsGroupBox7.Location = new Point(5, 3);
            nsGroupBox7.Name = "nsGroupBox7";
            nsGroupBox7.Size = new Size(1024, 42);
            nsGroupBox7.SubTitle = "";
            nsGroupBox7.TabIndex = 34;
            nsGroupBox7.Text = "nsGroupBox7";
            nsGroupBox7.Title = "";
            // 
            // nsButton4
            // 
            nsButton4.Location = new Point(880, 6);
            nsButton4.Name = "nsButton4";
            nsButton4.Size = new Size(138, 23);
            nsButton4.TabIndex = 33;
            nsButton4.Text = "Clear Output Window";
            nsButton4.Click += nsButton4_Click;
            // 
            // nsLabel18
            // 
            nsLabel18.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsLabel18.Location = new Point(3, 6);
            nsLabel18.Name = "nsLabel18";
            nsLabel18.Size = new Size(441, 23);
            nsLabel18.TabIndex = 31;
            nsLabel18.Text = "nsLabel18";
            nsLabel18.Value1 = "Bot Console View (Shows Logs, Errors, Disconnects, Etc.)";
            nsLabel18.Value2 = " ";
            // 
            // nsGroupBox9
            // 
            nsGroupBox9.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox9.Controls.Add(nsComboBox2);
            nsGroupBox9.Controls.Add(nsButton11);
            nsGroupBox9.Controls.Add(nsComboBox1);
            nsGroupBox9.Controls.Add(consolebtnSend);
            nsGroupBox9.Controls.Add(commandInputConsoleview);
            nsGroupBox9.Controls.Add(nsLabel21);
            nsGroupBox9.DrawSeperator = false;
            nsGroupBox9.Location = new Point(3, 381);
            nsGroupBox9.Name = "nsGroupBox9";
            nsGroupBox9.Size = new Size(1030, 101);
            nsGroupBox9.SubTitle = "";
            nsGroupBox9.TabIndex = 38;
            nsGroupBox9.Text = "nsGroupBox9";
            nsGroupBox9.Title = "";
            // 
            // nsComboBox2
            // 
            nsComboBox2.BackColor = Color.FromArgb(50, 50, 50);
            nsComboBox2.DrawMode = DrawMode.OwnerDrawFixed;
            nsComboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            nsComboBox2.ForeColor = Color.White;
            nsComboBox2.FormattingEnabled = true;
            nsComboBox2.Items.AddRange(new object[] { "1", "5", "10", "20", "30", "40", "50", "60", "70", "80", "90", "100", "200", "300", "400", "500" });
            nsComboBox2.Location = new Point(5, 65);
            nsComboBox2.Name = "nsComboBox2";
            nsComboBox2.Size = new Size(90, 24);
            nsComboBox2.TabIndex = 40;
            // 
            // nsButton11
            // 
            nsButton11.Enabled = false;
            nsButton11.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsButton11.Location = new Point(101, 63);
            nsButton11.Name = "nsButton11";
            nsButton11.Size = new Size(136, 29);
            nsButton11.TabIndex = 39;
            nsButton11.Text = "Purge Messages";
            nsButton11.Click += nsButton11_Click;
            // 
            // nsComboBox1
            // 
            nsComboBox1.BackColor = Color.FromArgb(50, 50, 50);
            nsComboBox1.DrawMode = DrawMode.OwnerDrawFixed;
            nsComboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            nsComboBox1.ForeColor = Color.White;
            nsComboBox1.FormattingEnabled = true;
            nsComboBox1.Location = new Point(5, 35);
            nsComboBox1.Name = "nsComboBox1";
            nsComboBox1.Size = new Size(232, 24);
            nsComboBox1.TabIndex = 38;
            // 
            // consolebtnSend
            // 
            consolebtnSend.Enabled = false;
            consolebtnSend.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            consolebtnSend.Location = new Point(947, 18);
            consolebtnSend.Name = "consolebtnSend";
            consolebtnSend.Size = new Size(79, 59);
            consolebtnSend.TabIndex = 37;
            consolebtnSend.Text = "Send";
            consolebtnSend.Click += consolebtnSend_Click;
            // 
            // commandInputConsoleview
            // 
            commandInputConsoleview.Location = new Point(243, 5);
            commandInputConsoleview.MaxLength = 32767;
            commandInputConsoleview.Multiline = true;
            commandInputConsoleview.Name = "commandInputConsoleview";
            commandInputConsoleview.ReadOnly = false;
            commandInputConsoleview.Size = new Size(698, 87);
            commandInputConsoleview.TabIndex = 35;
            commandInputConsoleview.TextAlign = HorizontalAlignment.Left;
            commandInputConsoleview.UseSystemPasswordChar = false;
            // 
            // nsLabel21
            // 
            nsLabel21.Font = new Font("Segoe UI Black", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsLabel21.Location = new Point(51, 5);
            nsLabel21.Name = "nsLabel21";
            nsLabel21.Size = new Size(145, 24);
            nsLabel21.TabIndex = 36;
            nsLabel21.Text = "nsLabel21";
            nsLabel21.Value1 = "Channel";
            nsLabel21.Value2 = " Selection";
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.FromArgb(50, 50, 50);
            tabPage3.Controls.Add(nsGroupBox10);
            tabPage3.Location = new Point(119, 4);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(1033, 483);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Moderation Panel";
            // 
            // nsGroupBox10
            // 
            nsGroupBox10.BackColor = Color.FromArgb(30, 30, 30);
            nsGroupBox10.Controls.Add(nsLabel30);
            nsGroupBox10.Controls.Add(nsLabel29);
            nsGroupBox10.Controls.Add(nsLabel28);
            nsGroupBox10.Controls.Add(nsGroupBox12);
            nsGroupBox10.Controls.Add(nsGroupBox11);
            nsGroupBox10.Controls.Add(nsLabel26);
            nsGroupBox10.Controls.Add(nsListView2);
            nsGroupBox10.Controls.Add(nsListView1);
            nsGroupBox10.DrawSeperator = false;
            nsGroupBox10.Location = new Point(3, 1);
            nsGroupBox10.Name = "nsGroupBox10";
            nsGroupBox10.Size = new Size(1027, 480);
            nsGroupBox10.SubTitle = "";
            nsGroupBox10.TabIndex = 39;
            nsGroupBox10.Text = "nsGroupBox10";
            nsGroupBox10.Title = "";
            // 
            // nsLabel30
            // 
            nsLabel30.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            nsLabel30.Location = new Point(115, 8);
            nsLabel30.Name = "nsLabel30";
            nsLabel30.Size = new Size(81, 17);
            nsLabel30.TabIndex = 57;
            nsLabel30.Text = "nsLabel30";
            nsLabel30.Value1 = "";
            nsLabel30.Value2 = " ";
            // 
            // nsLabel29
            // 
            nsLabel29.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            nsLabel29.Location = new Point(680, 7);
            nsLabel29.Name = "nsLabel29";
            nsLabel29.Size = new Size(81, 17);
            nsLabel29.TabIndex = 56;
            nsLabel29.Text = "nsLabel29";
            nsLabel29.Value1 = "";
            nsLabel29.Value2 = " ";
            // 
            // nsLabel28
            // 
            nsLabel28.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            nsLabel28.Location = new Point(554, 7);
            nsLabel28.Name = "nsLabel28";
            nsLabel28.Size = new Size(208, 17);
            nsLabel28.TabIndex = 55;
            nsLabel28.Text = "nsLabel28";
            nsLabel28.Value1 = "Server Members: ";
            nsLabel28.Value2 = " ";
            // 
            // nsGroupBox12
            // 
            nsGroupBox12.Controls.Add(nsButton12);
            nsGroupBox12.Controls.Add(nsTextBox2);
            nsGroupBox12.Controls.Add(label8);
            nsGroupBox12.Controls.Add(label9);
            nsGroupBox12.Controls.Add(label10);
            nsGroupBox12.Controls.Add(nsLabel27);
            nsGroupBox12.Controls.Add(nsButton9);
            nsGroupBox12.Controls.Add(nsButton10);
            nsGroupBox12.Controls.Add(label11);
            nsGroupBox12.Controls.Add(label12);
            nsGroupBox12.DrawSeperator = false;
            nsGroupBox12.Location = new Point(782, 8);
            nsGroupBox12.Name = "nsGroupBox12";
            nsGroupBox12.Size = new Size(238, 464);
            nsGroupBox12.SubTitle = "";
            nsGroupBox12.TabIndex = 54;
            nsGroupBox12.Text = "nsGroupBox12";
            nsGroupBox12.Title = "";
            // 
            // nsButton12
            // 
            nsButton12.Enabled = false;
            nsButton12.Location = new Point(59, 428);
            nsButton12.Name = "nsButton12";
            nsButton12.Size = new Size(55, 23);
            nsButton12.TabIndex = 55;
            nsButton12.Text = "Softban";
            nsButton12.Click += nsButton12_Click;
            // 
            // nsTextBox2
            // 
            nsTextBox2.Location = new Point(9, 92);
            nsTextBox2.MaxLength = 32767;
            nsTextBox2.Multiline = true;
            nsTextBox2.Name = "nsTextBox2";
            nsTextBox2.ReadOnly = false;
            nsTextBox2.Size = new Size(216, 330);
            nsTextBox2.TabIndex = 54;
            nsTextBox2.TextAlign = HorizontalAlignment.Left;
            nsTextBox2.UseSystemPasswordChar = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.White;
            label8.Location = new Point(9, 29);
            label8.Name = "label8";
            label8.Size = new Size(63, 15);
            label8.TabIndex = 50;
            label8.Text = "Username:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.White;
            label9.Location = new Point(9, 50);
            label9.Name = "label9";
            label9.Size = new Size(44, 15);
            label9.TabIndex = 49;
            label9.Text = "UserID:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.White;
            label10.Location = new Point(9, 74);
            label10.Name = "label10";
            label10.Size = new Size(98, 15);
            label10.TabIndex = 48;
            label10.Text = "Kick/Ban Reason:";
            // 
            // nsLabel27
            // 
            nsLabel27.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsLabel27.Location = new Point(5, 3);
            nsLabel27.Name = "nsLabel27";
            nsLabel27.Size = new Size(228, 23);
            nsLabel27.TabIndex = 40;
            nsLabel27.Text = "nsLabel27";
            nsLabel27.Value1 = "Connected User";
            nsLabel27.Value2 = " Details";
            // 
            // nsButton9
            // 
            nsButton9.Enabled = false;
            nsButton9.Location = new Point(120, 428);
            nsButton9.Name = "nsButton9";
            nsButton9.Size = new Size(105, 23);
            nsButton9.TabIndex = 47;
            nsButton9.Text = "Ban";
            nsButton9.Click += nsButton9_Click;
            // 
            // nsButton10
            // 
            nsButton10.Enabled = false;
            nsButton10.Location = new Point(9, 428);
            nsButton10.Name = "nsButton10";
            nsButton10.Size = new Size(44, 23);
            nsButton10.TabIndex = 46;
            nsButton10.Text = "Kick";
            nsButton10.Click += nsButton10_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = Color.White;
            label11.Location = new Point(53, 50);
            label11.Name = "label11";
            label11.Size = new Size(0, 15);
            label11.TabIndex = 53;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = Color.White;
            label12.Location = new Point(70, 29);
            label12.Name = "label12";
            label12.Size = new Size(0, 15);
            label12.TabIndex = 52;
            // 
            // nsGroupBox11
            // 
            nsGroupBox11.Controls.Add(nsTextBox1);
            nsGroupBox11.Controls.Add(label5);
            nsGroupBox11.Controls.Add(label4);
            nsGroupBox11.Controls.Add(label3);
            nsGroupBox11.Controls.Add(nsLabel24);
            nsGroupBox11.Controls.Add(nsButton8);
            nsGroupBox11.Controls.Add(nsButton7);
            nsGroupBox11.Controls.Add(label7);
            nsGroupBox11.Controls.Add(label6);
            nsGroupBox11.DrawSeperator = false;
            nsGroupBox11.Location = new Point(295, 8);
            nsGroupBox11.Name = "nsGroupBox11";
            nsGroupBox11.Size = new Size(245, 464);
            nsGroupBox11.SubTitle = "";
            nsGroupBox11.TabIndex = 48;
            nsGroupBox11.Text = "nsGroupBox11";
            nsGroupBox11.Title = "";
            // 
            // nsTextBox1
            // 
            nsTextBox1.Enabled = false;
            nsTextBox1.Location = new Point(10, 92);
            nsTextBox1.MaxLength = 32767;
            nsTextBox1.Multiline = true;
            nsTextBox1.Name = "nsTextBox1";
            nsTextBox1.ReadOnly = true;
            nsTextBox1.Size = new Size(222, 330);
            nsTextBox1.TabIndex = 51;
            nsTextBox1.TextAlign = HorizontalAlignment.Left;
            nsTextBox1.UseSystemPasswordChar = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.White;
            label5.Location = new Point(10, 29);
            label5.Name = "label5";
            label5.Size = new Size(63, 15);
            label5.TabIndex = 50;
            label5.Text = "Username:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.White;
            label4.Location = new Point(10, 50);
            label4.Name = "label4";
            label4.Size = new Size(44, 15);
            label4.TabIndex = 49;
            label4.Text = "UserID:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.White;
            label3.Location = new Point(10, 74);
            label3.Name = "label3";
            label3.Size = new Size(71, 15);
            label3.TabIndex = 48;
            label3.Text = "Ban Reason:";
            // 
            // nsLabel24
            // 
            nsLabel24.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsLabel24.Location = new Point(10, 3);
            nsLabel24.Name = "nsLabel24";
            nsLabel24.Size = new Size(180, 23);
            nsLabel24.TabIndex = 40;
            nsLabel24.Text = "nsLabel24";
            nsLabel24.Value1 = "Users Ban";
            nsLabel24.Value2 = " Details";
            // 
            // nsButton8
            // 
            nsButton8.Enabled = false;
            nsButton8.Location = new Point(124, 428);
            nsButton8.Name = "nsButton8";
            nsButton8.Size = new Size(108, 23);
            nsButton8.TabIndex = 47;
            nsButton8.Text = "Save to Ban File";
            nsButton8.Click += nsButton8_Click;
            // 
            // nsButton7
            // 
            nsButton7.Enabled = false;
            nsButton7.Location = new Point(10, 428);
            nsButton7.Name = "nsButton7";
            nsButton7.Size = new Size(63, 23);
            nsButton7.TabIndex = 46;
            nsButton7.Text = "Unban";
            nsButton7.Click += nsButton7_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = Color.White;
            label7.Location = new Point(52, 50);
            label7.Name = "label7";
            label7.Size = new Size(0, 15);
            label7.TabIndex = 53;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.White;
            label6.Location = new Point(72, 29);
            label6.Name = "label6";
            label6.Size = new Size(0, 15);
            label6.TabIndex = 52;
            // 
            // nsLabel26
            // 
            nsLabel26.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsLabel26.Location = new Point(6, 8);
            nsLabel26.Name = "nsLabel26";
            nsLabel26.Size = new Size(265, 17);
            nsLabel26.TabIndex = 44;
            nsLabel26.Text = "nsLabel26";
            nsLabel26.Value1 = " ";
            nsLabel26.Value2 = " Banned Users:";
            // 
            // nsListView2
            // 
            nsListView2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsListView2.ForeColor = Color.White;
            nsListView2.Location = new Point(551, 3);
            nsListView2.MultiSelect = true;
            nsListView2.Name = "nsListView2";
            nsListView2.Size = new Size(230, 467);
            nsListView2.TabIndex = 49;
            nsListView2.Text = "nsListView2";
            nsListView2.SelectedIndexChanged += nsListView2_SelectedIndexChanged;
            // 
            // nsListView1
            // 
            nsListView1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nsListView1.ForeColor = Color.White;
            nsListView1.Location = new Point(4, 5);
            nsListView1.MultiSelect = false;
            nsListView1.Name = "nsListView1";
            nsListView1.Size = new Size(285, 467);
            nsListView1.TabIndex = 45;
            nsListView1.Text = "nsListView1";
            nsListView1.SelectedIndexChanged += nsListView1_SelectedIndexChanged;
            // 
            // notifyIcon1
            // 
            notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
            notifyIcon1.BalloonTipText = "Bot is running in the background...";
            notifyIcon1.BalloonTipTitle = "VoidBot Discord Bot";
            notifyIcon1.ContextMenuStrip = nsContextMenu1;
            notifyIcon1.Icon = (Icon)resources.GetObject("notifyIcon1.Icon");
            notifyIcon1.MouseDoubleClick += notifyIcon1_MouseDoubleClick;
            notifyIcon1.MouseMove += notifyIcon1_MouseMove;
            // 
            // nsContextMenu1
            // 
            nsContextMenu1.ForeColor = Color.White;
            nsContextMenu1.Items.AddRange(new ToolStripItem[] { openBotPanelToolStripMenuItem, closeBotToolStripMenuItem });
            nsContextMenu1.Name = "nsContextMenu1";
            nsContextMenu1.Size = new Size(157, 48);
            nsContextMenu1.Text = "File...";
            // 
            // openBotPanelToolStripMenuItem
            // 
            openBotPanelToolStripMenuItem.Name = "openBotPanelToolStripMenuItem";
            openBotPanelToolStripMenuItem.Size = new Size(156, 22);
            openBotPanelToolStripMenuItem.Text = "Open Bot Panel";
            openBotPanelToolStripMenuItem.Click += openBotPanelToolStripMenuItem_Click;
            // 
            // closeBotToolStripMenuItem
            // 
            closeBotToolStripMenuItem.Name = "closeBotToolStripMenuItem";
            closeBotToolStripMenuItem.Size = new Size(156, 22);
            closeBotToolStripMenuItem.Text = "Close Bot...";
            closeBotToolStripMenuItem.Click += closeBotToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1155, 486);
            Controls.Add(nsTabControl1);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "Form1";
            Text = "VoidBot Discord Bot [GUI]";
            Load += Form1_Load;
            nsTabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            nsGroupBox3.ResumeLayout(false);
            nsGroupBox2.ResumeLayout(false);
            nsGroupBox1.ResumeLayout(false);
            nsGroupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            nsGroupBox5.ResumeLayout(false);
            nsGroupBox5.PerformLayout();
            nsGroupBox6.ResumeLayout(false);
            nsGroupBox8.ResumeLayout(false);
            nsGroupBox8.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            nsGroupBox7.ResumeLayout(false);
            nsGroupBox9.ResumeLayout(false);
            tabPage3.ResumeLayout(false);
            nsGroupBox10.ResumeLayout(false);
            nsGroupBox12.ResumeLayout(false);
            nsGroupBox12.PerformLayout();
            nsGroupBox11.ResumeLayout(false);
            nsGroupBox11.PerformLayout();
            nsContextMenu1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private NSTabControl nsTabControl1;
        private TabPage tabPage1;
        private NSGroupBox nsGroupBox3;
        private NSLabel nsLabel16;
        private NSLabel nsLabel13;
        private NSLabel nsLabel12;
        private NSLabel nsLabel11;
        private NSLabel nsLabel14;
        private NSLabel nsLabel15;
        private NSGroupBox nsGroupBox2;
        private NSLabel nsLabel7;
        private NSGroupBox nsGroupBox1;
        private NSCheckBox nsCheckBox1;
        private NSLabel nsLabel6;
        private NSLabel nsLabel4;
        private NSLabel nsLabel3;
        private NSLabel nsLabel2;
        private NSGroupBox nsGroupBox4;
        private NSLabel nsLabel19;
        private NSGroupBox nsGroupBox5;
        public Label label2;
        private Label label1;
        private NSGroupBox nsGroupBox6;
        private TabPage tabPage2;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel1;
        private NSLabel nsLabel18;
        private NSButton nsButton4;
        private NSGroupBox nsGroupBox7;
        private NotifyIcon notifyIcon1;
        private NSButton nsButton5;
        private NSContextMenu nsContextMenu1;
        private ToolStripMenuItem openBotPanelToolStripMenuItem;
        private ToolStripMenuItem closeBotToolStripMenuItem;
        private NSGroupBox nsGroupBox8;
        private NSButton consolebtnSend;
        private NSLabel nsLabel21;
        private NSTextBox commandInputConsoleview;
        private NSGroupBox nsGroupBox9;
        public NSComboBox nsComboBox1;
        public TextBox botConsoleView;
        private NSLabel nsLabel23;
        private NSButton nsButton11;
        private NSComboBox nsComboBox2;
        public PictureBox pictureBox1;
        public NSLabel nsLabel22;
        public NSTextBox BotNickname;
        public NSTextBox InviteLink;
        public NSTextBox YoutubeAPIKey;
        public NSTextBox YoutubeAppName;
        public NSTextBox DiscordBotToken;
        public NSLabel nsLabel20;
        public NSTextBox ServerID;
        private LinkLabel linkLabel3;
        public System.Windows.Forms.Timer timer1;
        public NSComboBox nsComboBox7;
        public NSComboBox nsComboBox9;
        public NSComboBox nsComboBox8;
        public NSComboBox nsComboBox11;
        public NSComboBox nsComboBox10;
        private NSLabel nsLabel43;
        private NSLabel nsLabel42;
        public NSButton nsButton3;
        public NSButton nsButton1;
        private NSButton nsButton2;
        private NSLabel nsLabel45;
        public NSTextBox MongoDBName;
        private NSLabel nsLabel44;
        public NSTextBox MongoClientLink;
        private Label label23;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private NSButton nsButton21;
        private NSCheckBox nsCheckBox4;
        private TabPage tabPage3;
        private NSGroupBox nsGroupBox10;
        private NSTextBox nsTextBox9;
        private NSCheckBox nsCheckBox3;
        private NSComboBox nsComboBox6;
        private NSLabel nsLabel40;
        private NSCheckBox nsCheckBox2;
        public NSComboBox nsComboBox4;
        private NSLabel nsLabel38;
        private DateTimePicker dateTimePicker1;
        private NSButton nsButton16;
        private NSLabel nsLabel39;
        private NSButton nsButton6;
        private NSButton nsButton15;
        public NSLabel nsLabel30;
        public NSLabel nsLabel29;
        private NSLabel nsLabel28;
        private NSGroupBox nsGroupBox12;
        private NSButton nsButton12;
        private NSTextBox nsTextBox2;
        private Label label8;
        private Label label9;
        private Label label10;
        private NSLabel nsLabel27;
        private NSButton nsButton9;
        private NSButton nsButton10;
        private Label label11;
        private Label label12;
        private NSGroupBox nsGroupBox11;
        private NSTextBox nsTextBox1;
        private Label label5;
        private Label label4;
        private Label label3;
        private NSLabel nsLabel24;
        private NSButton nsButton8;
        private NSButton nsButton7;
        private Label label7;
        private Label label6;
        private NSLabel nsLabel26;
        public NSListView nsListView2;
        public NSListView nsListView1;
        private NSLabel nsLabel25;
        private NSLabel nsLabel41;
        private NSSeperator nsSeperator2;
    }
}
